class courseDTO{
    constructor(course){
        this._id=course._id,
        this.name=course.name
    }
}
module.exports=courseDTO

