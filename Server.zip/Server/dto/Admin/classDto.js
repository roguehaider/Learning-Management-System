class classDTO{
    constructor(clas){
        this._id=clas._id,
        this.name=clas.name
    }
}
module.exports=classDTO

