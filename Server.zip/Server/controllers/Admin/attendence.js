const Attendence = require('../../models/attendence')

async function getAttendenceOfStudent(req , res , next){

    const {roll_No} = req.body

    
}